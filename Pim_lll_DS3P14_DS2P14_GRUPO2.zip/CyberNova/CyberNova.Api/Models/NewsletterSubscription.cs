using System;
using System.ComponentModel.DataAnnotations;

namespace CyberNova.Api.Models
{
    public class NewsletterSubscription
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [EmailAddress]
        [MaxLength(150)]
        public string Email { get; set; } = string.Empty;

        public DateTime SubscribedAt { get; set; } = DateTime.UtcNow;
    }
}