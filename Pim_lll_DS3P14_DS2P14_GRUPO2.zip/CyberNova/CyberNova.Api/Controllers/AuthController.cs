using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CyberNova.Api.Data;
using CyberNova.Api.DTOs;
using CyberNova.Api.Models;
using CyberNova.Api.Services;

namespace CyberNova.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
            {
                return BadRequest(new { error = "Este e-mail já está em uso." });
            }

            var (hash, salt) = SecurityService.HashPassword(dto.Password);

            var newUser = new User
            {
                FullName = dto.FullName,
                Email = dto.Email,
                PasswordHash = hash,
                PasswordSalt = salt
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Usuário registrado com sucesso!" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);
            
            if (user == null)
            {
                return Unauthorized(new { error = "Credenciais inválidas." });
            }

            var isValid = SecurityService.VerifyPassword(dto.Password, user.PasswordHash, user.PasswordSalt);

            if (!isValid)
            {
                return Unauthorized(new { error = "Credenciais inválidas." });
            }

            return Ok(new 
            { 
                message = "Login efetuado com sucesso!",
                user = new { id = user.Id, name = user.FullName, email = user.Email }
            });
        }
    }
}