using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CyberNova.Api.Data;
using CyberNova.Api.DTOs;
using CyberNova.Api.Models;

namespace CyberNova.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NewsletterController : ControllerBase
    {
        private readonly AppDbContext _context;

        public NewsletterController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("subscribe")]
        public async Task<IActionResult> Subscribe([FromBody] NewsletterDto dto)
        {
            bool alreadySubscribed = await _context.NewsletterSubscriptions
                                                   .AnyAsync(n => n.Email == dto.Email);
            
            if (alreadySubscribed)
            {
                return BadRequest(new { error = "Este e-mail já está inscrito em nossa newsletter." });
            }

            var novaInscricao = new NewsletterSubscription
            {
                Email = dto.Email
            };

            _context.NewsletterSubscriptions.Add(novaInscricao);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Inscrição realizada com sucesso! Bem-vindo(a) à CyberNova." });
        }
    }
}