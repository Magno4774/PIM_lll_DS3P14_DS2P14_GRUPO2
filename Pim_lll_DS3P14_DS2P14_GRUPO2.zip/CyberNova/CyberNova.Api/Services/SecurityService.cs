using System;
using System.Security.Cryptography;
using System.Text;

namespace CyberNova.Api.Services
{
    public static class SecurityService
    {
        private const int KeySize = 64;
        private const int Iterations = 350000;
        private static readonly HashAlgorithmName HashAlgorithm = HashAlgorithmName.SHA512;

        public static (string Hash, string Salt) HashPassword(string password)
        {
            var salt = RandomNumberGenerator.GetBytes(KeySize);
            var hash = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                salt,
                Iterations,
                HashAlgorithm,
                KeySize);

            return (Convert.ToHexString(hash), Convert.ToHexString(salt));
        }

        public static bool VerifyPassword(string password, string hashHex, string saltHex)
        {
            var salt = Convert.FromHexString(saltHex);
            var hashToCompare = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                salt,
                Iterations,
                HashAlgorithm,
                KeySize);

            return CryptographicOperations.FixedTimeEquals(hashToCompare, Convert.FromHexString(hashHex));
        }
    }
}